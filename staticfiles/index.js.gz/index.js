// ClassicEditor
// 				.create( document.querySelector( '.editor' ), {

// 				toolbar: {
// 					items: [
// 						'redo',
// 						'undo',
// 						'insertTable',
// 						'bulletedList',
// 						'numberedList',
// 						'italic',
// 						'outdent',
// 						'indent',
// 						'link',
// 						'bold',
// 						'blockQuote',
// 						'heading'
// 					]
// 				},
// 				language: 'en',
// 				table: {
// 					contentToolbar: [
// 						'tableColumn',
// 						'tableRow',
// 						'mergeTableCells'
// 					]
// 				},
// 					licenseKey: '',



// 				} )
// 				.then( editor => {
// 					window.editor = editor;

// 					console.log('editor..')


// 				} )
// 				.catch( error => {
// 					console.error( 'Oops, something went wrong!' );
// 					console.error( 'Please, report the following error on https://github.com/ckeditor/ckeditor5/issues with the build id and the error stack trace:' );
// 					console.warn( 'Build id: tqrrn2uhe9hn-f0hzn61q8yoo' );
// 					console.error( error );
// 				} );

